package com.example.basketball_scores

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
